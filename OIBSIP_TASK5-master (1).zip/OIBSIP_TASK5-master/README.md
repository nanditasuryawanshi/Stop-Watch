<h1 align="center">
  Stop-Watch-App
</h1>

## Stop-Watch-App
  StopWatch is an app which act as aStop Watch. Android Application which starts on pressing button start and stop by stop button there is also reset button to reset the time.
With Good UI and extra implementation.


 

## App Control
Just click on the Start Button and the time start running with millisecond as a low limit.
stop - Stop the time.
reset- Reset the time.

## Showcase
